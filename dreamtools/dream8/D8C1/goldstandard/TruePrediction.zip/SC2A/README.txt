these files contains the true prediction for SC2A:

    BT20_main_Test.csv
    BT549_main_Test.csv
    MCF7_main_Test.csv
    UACC812_main_Test.csv

